
#include "acquisition.h"

#include <malloc.h>
#include <string.h>
#include <math.h>

#define N_SAMPLES 1000 // number of samples
#define M 2048 // size of the arrays for the chirp Z-transform (M >= N_SAMPLES * 2 -1)
#define N_LEVELS 11 // number of levels used in the radix-2 algorithm
#define SAMPLING_FREQ 2000000 // sampling frequency of 2MHz
#define GAMMA 0.015f // limit value for acquisition
#define FREQ_COUNT 4 // number of frequencies to test
#define PI 3.14159265f

// function for swapping values in FFT algorithm
#define SWAP(a, b) tempr=(a); (a)=(b); (b)=tempr

typedef struct {
    int32_t codePhase;
    int32_t dopplerFrequency;
    // internal state for acquisition
    int32_t sampleCount; // index for sample entries
    float* samplesReal; // array of real part of samples
    float* samplesImag; // array of real part of samples
    int32_t codeCount; // index for code entries
    float* codesReal; // array of real part of codes
    float* codesImag; // array of imaginary part of codes
    // arrays for performing the acquisition algorithm itself
    float (*realX)[N_SAMPLES];
    float (*imagX)[N_SAMPLES];
    float (*realR)[N_SAMPLES];
    float (*imagR)[N_SAMPLES];
    // array used in radix-2 algorithm
    float* data;
    // arrays used in complex convolution
    float* xr;
    float* xi;
    float* yr;
    float* yi;
    // arrays used in bluestein algorithm
    float* cosTable;
    float* sinTable;
    float* areal;
    float* aimag;
    float* breal;
    float* bimag;
    float* creal;
    float* cimag;

} acquisitionInternal_t;

acquisition_t* allocateAcquisition(int32_t nrOfSamples) {
    acquisitionInternal_t * a = malloc(sizeof(acquisitionInternal_t));

    memset(a, 0, sizeof(acquisitionInternal_t)); // to initialize everything to a defined state (=0)

    a->realX = malloc(sizeof(float[FREQ_COUNT][nrOfSamples]));
    a->imagX = malloc(sizeof(float[FREQ_COUNT][nrOfSamples]));
    a->realR = malloc(sizeof(float[FREQ_COUNT][nrOfSamples]));
    a->imagR = malloc(sizeof(float[FREQ_COUNT][nrOfSamples]));
    memset(a->realX, 0, (FREQ_COUNT * nrOfSamples) * sizeof(float));
    memset(a->imagX, 0, (FREQ_COUNT * nrOfSamples) * sizeof(float));
    memset(a->realR, 0, (FREQ_COUNT * nrOfSamples) * sizeof(float));
    memset(a->imagR, 0, (FREQ_COUNT * nrOfSamples) * sizeof(float));

    a->data = malloc(M * 2 * sizeof(float));
    
    a->xr = malloc(M * sizeof(float));
    a->xi = malloc(M * sizeof(float));
    a->yr = malloc(M * sizeof(float));
    a->yi = malloc(M * sizeof(float));

    a->cosTable = malloc(nrOfSamples * sizeof(float));
    a->sinTable = malloc(nrOfSamples * sizeof(float));
    a->areal = malloc(M * sizeof(float));
    a->aimag = malloc(M * sizeof(float));
    a->breal = malloc(M * sizeof(float));
    a->bimag = malloc(M * sizeof(float));
    a->creal = malloc(M * sizeof(float));
    a->cimag = malloc(M * sizeof(float));
    memset(a->areal, 0, M * sizeof(float));
    memset(a->aimag, 0, M * sizeof(float));
    memset(a->breal, 0, M * sizeof(float));
    memset(a->bimag, 0, M * sizeof(float));
    memset(a->creal, 0, M * sizeof(float));
    memset(a->cimag, 0, M * sizeof(float));

    a->samplesReal = malloc(nrOfSamples * sizeof(float));
    a->samplesImag = malloc(nrOfSamples * sizeof(float));
    a->sampleCount = 0;
    
    a->codesReal = malloc(nrOfSamples * sizeof(float));
    a->codesImag = malloc(nrOfSamples * sizeof(float));
    a->codeCount = 0;

    return (acquisition_t*)a;
}

void deleteAcquisition(acquisition_t* acq) {
    acquisitionInternal_t * a = (acquisitionInternal_t*) acq;

    // free also everything else that was allocated in [allocateAcquisition]
    free(a->realX);
    free(a->imagX);
    free(a->realR);
    free(a->imagR);
    free(a->data);
    free(a->xr);
    free(a->xi);
    free(a->yr);
    free(a->yi);
    free(a->cosTable);
    free(a->sinTable);
    free(a->areal);
    free(a->aimag);
    free(a->breal);
    free(a->bimag);
    free(a->creal);
    free(a->cimag);
    free(a->samplesReal);
    free(a->samplesImag);
    free(a->codesReal);
    free(a->codesImag);
    // after freeing all contained structures on heap, free acq itself
    free(acq);
}

void enterSample(acquisition_t* acq, float real, float imag) {
    acquisitionInternal_t * a = (acquisitionInternal_t*) acq;

    // put a sample-entry into the state in [a]

    // Example
    a->samplesReal[a->sampleCount] = real;
    a->samplesImag[a->sampleCount] = imag;
    a->sampleCount += 1;
}

void enterCode(acquisition_t* acq, float real, float imag) {
    acquisitionInternal_t * a = (acquisitionInternal_t*) acq;

    // put a code-entry into the state in [a]
    a->codesReal[a->codeCount] = real;
    a->codesImag[a->codeCount] = imag;
    a->codeCount += 1;
}

static int reverseBits(int val, int width) {
	int result = 0;
	for (int i = 0; i < width; i++, val >>= 1)
		result = (result << 1) | (val & 1U);
	return result;
}

/*
    Radix-2 FFT algorithm taken from 
    https://www.codeproject.com/Articles/9388/How-to-implement-the-FFT-algorithm
    (based on "Numerical Recipes in C"), which uses
    the radix-2 Decimation In Time (DIT) implementation of FFT.
    The number of samples must be a power of 2.
    If the argument `isign` is given as -1, the Discrete Fourier Transform (DFT)
    is calculated. If it is given as 1, the unscaled
    Inverse Discrete Fourier Transform (IDFT) is calculated
    (in order to obtain the exact IDFT, the given data must be divided
    by the number of samples)  
*/
void radix2(acquisitionInternal_t* a, float* real, float* imag, int isign) {
    float wtemp, wr, wpr, wpi, wi, theta;
    float tempr, tempi;
    int n, mmax, m, i, j, k, istep, update;
    int levels = N_LEVELS;

    n = M * 2;

    // perform bit reversal (according to "butterfly diagram"),
    // with the real part on the even indexes and the complex
    // part on the odd indexes
    for(i = 0; i < M; i++) {
        j = reverseBits(i, levels);
        if(j > i) {
            float temp = real[i];
            real[i] = real[j];
            real[j] = temp;
            temp = imag[i];
            imag[i] = imag[j];
            imag[j] = temp;
        }
    }

    // copy input data (real and imaginary parts) into a single array
    for(i = 0, j = 0; i < n; i += 2, j++) {
        a->data[i] = real[j];
        a->data[i+1] = imag[j];
    }

    // Danielson-Lanzcos routine
    mmax = 2;
    // external loop
    while(n > mmax) {
        istep = mmax <<  1;
        theta = isign * (2 * PI / mmax);
        wtemp = sinf(0.5f * theta);
        wpr = -2.0f * wtemp * wtemp;
        wpi = sinf(theta);
        wr = 1.0f;
        wi = 0.0f;
        // internal loops
        for(m = 1; m < mmax; m += 2) {
            for(i = m; i <= n; i += istep) {
                j = i + mmax;
                tempr = wr * a->data[j-1] - wi * a->data[j];
                tempi = wr * a->data[j] + wi * a->data[j-1];
                a->data[j-1] = a->data[i-1] - tempr;
                a->data[j] = a->data[i] - tempi;
                a->data[i-1] += tempr;
                a->data[i] += tempi;
            }
            wtemp = wr;
            wr += wtemp * wpr - wi * wpi;
            wi += wi * wpr + wtemp * wpi;
        }
        mmax = istep;
    }

    for(i = 0, j = 0; i < n; i += 2, j++) {
        real[j] = a->data[i];
        imag[j] = a->data[i+1];
    }
}

/*
    performs the complex convolution of the two sequences used
    in the chirp Z-transform
*/
void complexConvolution(acquisitionInternal_t* a,
    const float* xreal, const float* ximag,
    const float* yreal, const float* yimag,
    float* outreal, float* outimag) {
	
    float temp = 0.0;
    int size = M * sizeof(float);

    memcpy(a->xr, xreal, size);
    memcpy(a->xi, ximag, size);
    memcpy(a->yr, yreal, size);
    memcpy(a->yi, yimag, size);

    // compute FFTs of arrays needed for convolution
    radix2(a, a->xr, a->xi, -1);
    radix2(a, a->yr, a->yi, -1);

    for(int i = 0; i < M; i++) {
        temp = a->xr[i] * a->yr[i] - a->xi[i] * a->yi[i];
        a->xi[i] = a->xi[i] * a->yr[i] + a->xr[i] * a->yi[i];
        a->xr[i] = temp;
    }

    // compute inverse FFT needed for convolution
    radix2(a, a->xr, a->xi, 1);

    // scale the result
    for(int i = 0; i < M; i++) {
        outreal[i] = a->xr[i] / M;
        outimag[i] = a->xi[i] / M;
    }
}

/*
    Bluestein's algorithm for calculating FFTs for an array
    of samples of arbitrary length, using a complex convolution
*/
void bluestein(acquisitionInternal_t* a, float* real, float* imag) {    
    int temp = 0;
    float angle = 0.0;
    

    /*
    for(int i = 0; i < N_SAMPLES; i++) {
        temp = (i * i) % (N_SAMPLES * 2);
        angle = PI * temp / N_SAMPLES;
        a->cosTable[i] = cosf(angle);
        a->sinTable[i] = sinf(angle);
    }
    */

    // temporary arrays and preprocessing
    for(int i = 0, j = 1; i < N_SAMPLES; i++, j++) {
        temp = (i * i) % (N_SAMPLES * 2);
        angle = PI * temp / N_SAMPLES;
        a->cosTable[i] = cosf(angle);
        a->sinTable[i] = sinf(angle);
        a->areal[i] = real[i] * a->cosTable[i] + imag[i] * a->sinTable[i];
        a->aimag[i] = -real[i] * a->sinTable[i] + imag[i] * a->cosTable[i];
    }

    a->breal[0] = a->cosTable[0];
    a->bimag[0] = a->sinTable[0];


    for(int i = 1; i < N_SAMPLES; i++) {
        a->breal[i] = a->breal[M-i] = a->cosTable[i];
        a->bimag[i] = a->bimag[M-i] = a->sinTable[i];
    }


    // convolution
    complexConvolution(a, a->areal, a->aimag, a->breal, a->bimag, a->creal, a->cimag);

    // postprocessing
    for(int i = 0; i < N_SAMPLES; i++) {
        real[i] = a->creal[i] * a->cosTable[i] + a->cimag[i] * a->sinTable[i];
        imag[i] = -a->creal[i] * a->sinTable[i] + a->cimag[i] * a->cosTable[i];
    }
}

/*
    Free FFT and convolution (C)
    Copyright (c) 2021 Project Nayuki. (MIT License)
    https://www.nayuki.io/page/free-small-fft-in-multiple-languages

*/
void fft(acquisitionInternal_t* a, float* real, float* imag) {
    // if it is a power of two, use radix 2 algorithm
    if((N_SAMPLES & (N_SAMPLES-1)) == 0) {
        radix2(a, real, imag, -1);
    }
    // otherwise, use bluestein algorithm
    else {
        bluestein(a, real, imag);
    }
}

void inverseFft(acquisitionInternal_t* a, float* real, float* imag) {
    fft(a, imag, real);
}

void buildX(
	float* realX, float* imagX,
	float* samplesReal, float* samplesImag,
	int32_t frequency) {

	float angle = 0.0;
    float cos = 0.0;
    float sin = 0.0;

	for(int32_t n = 0; n < N_SAMPLES; n++) {
        angle = 2 * PI * frequency * n / SAMPLING_FREQ;
        cos = cosf(angle);
        sin = sinf(angle);
        realX[n] = samplesReal[n] * cos + samplesImag[n] * sin;
        imagX[n] = -samplesReal[n] * sin + samplesImag[n] * cos;
    }
}

void buildR(
	float* realR, float* imagR,
	float* realX, float* imagX,
	float* codesReal, float* codesImag) {

	for(int32_t n = 0; n < N_SAMPLES; n++) {
        realR[n] = realX[n] * codesReal[n] - imagX[n] * codesImag[n];
        imagR[n] = realX[n] * codesImag[n] + imagX[n] * codesReal[n];
    }
}

void scaleIdft(float* realR, float* imagR) {
	for(int32_t n = 0; n < N_SAMPLES; n++) {
        realR[n] /= (N_SAMPLES * N_SAMPLES);
        imagR[n] /= (N_SAMPLES * N_SAMPLES);
    }
}

float getMaxValue(acquisitionInternal_t* a,
	float* realR, float* imagR,
	float sMax, int32_t frequency) {

	float absValue = 0.0;

	for(int32_t n = 0; n < N_SAMPLES; n++) {
        absValue = realR[n] * realR[n] + imagR[n] * imagR[n];
        if(absValue > sMax) {
            sMax = absValue;
            a->codePhase = N_SAMPLES - n;
            a->dopplerFrequency = frequency;
        }
    }
    return sMax;
}

float calculatePin(float* samplesReal, float* samplesImag) {
	float pIn = 0.0;

	for(int32_t n = 0; n < N_SAMPLES; n++) {
        pIn += samplesReal[n] * samplesReal[n] + samplesImag[n] * samplesImag[n];
    }

	return (pIn / N_SAMPLES);
}

__attribute__((noipa))
bool startAcquisition(acquisition_t* acq, int32_t testFreqCount, const int32_t* testFrequencies) {
    acquisitionInternal_t * a = (acquisitionInternal_t*) acq;

    float angle = 0.0;
    float cos = 0.0;
    float sin = 0.0;
    float absValue = 0.0;
    float sMax = 0.0;
    float pIn = 0.0;

    // calculate DFT of codes
    
    fft(a, a->codesReal, a->codesImag);
    
    // compute conjugate of the DFT of codes
    for(int32_t n = 0; n < N_SAMPLES; n++) {
        a->codesImag[n] = -a->codesImag[n];
    }

    for(int32_t f = 0; f < testFreqCount; f++) {
        // construct Xfd
        buildX(a->realX[f], a->imagX[f], a->samplesReal, a->samplesImag, testFrequencies[f]);

        // calculate the DFT of Xfd
        fft(a, a->realX[f], a->imagX[f]);

        // construct R
        buildR(a->realR[f], a->imagR[f], a->realX[f], a->imagX[f], a->codesReal, a->codesImag);

        // calculate IDFT of R
        fft(a, a->realR[f], a->imagR[f]);
        // scale the IDFT
        scaleIdft(a->realR[f], a->imagR[f]);

        // obtain maximum value
        sMax = getMaxValue(a, a->realR[f], a->imagR[f], sMax, testFrequencies[f]);

    }

    pIn = calculatePin(a->samplesReal, a->samplesImag);
    bool result = ((sMax / pIn) > GAMMA);
    return result; // return whether acquisition was achieved or not!
}
